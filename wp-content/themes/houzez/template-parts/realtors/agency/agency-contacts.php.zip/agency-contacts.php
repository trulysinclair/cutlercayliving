<div class="agent-contacts-wrap">
	<h3 class="widget-title"><?php esc_html_e('Contact', 'houzez'); ?></h3>
	<div class="agent-map">
		<?php get_template_part('template-parts/realtors/agency/image'); ?>
		<?php get_template_part('template-parts/realtors/agency/address'); ?>
	</div>
	<ul class="list-unstyled">
		<?php get_template_part('template-parts/realtors/agency/office-phone'); ?>
		<?php get_template_part('template-parts/realtors/agency/mobile'); ?>
		<?php get_template_part('template-parts/realtors/agency/fax'); ?>
		<?php get_template_part('template-parts/realtors/agency/email'); ?>
		<?php get_template_part('template-parts/realtors/agency/website'); ?>
	</ul>
	<p><?php printf( esc_html__( 'Find %s on', 'houzez' ) , get_the_title() ); ?>:</p>
	<div class="agent-social-media">
		<?php get_template_part('template-parts/realtors/agency/social'); ?>
	</div><!-- agent-social-media -->
</div><!-- agent-bio-wrap -->